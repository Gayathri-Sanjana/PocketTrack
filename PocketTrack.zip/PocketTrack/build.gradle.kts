plugins {
    id("com.android.application") version "8.9.2"
    id("org.jetbrains.kotlin.android") version "1.8.20"
}
