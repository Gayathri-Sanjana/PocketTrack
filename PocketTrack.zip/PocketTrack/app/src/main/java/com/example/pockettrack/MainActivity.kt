package com.example.pockettrack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pockettrack.data.AppDatabase
import com.example.pockettrack.ui.ExpenseScreen
import com.example.pockettrack.viewmodel.ExpenseViewModel
import com.example.pockettrack.viewmodel.ExpenseViewModelFactory
import com.example.pockettrack.ui.theme.PocketTrackTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Database using the getDatabase method (Singleton)
        val database = AppDatabase.getDatabase(applicationContext)

        setContent {
            PocketTrackTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val expenseDao = database.expenseDao()
                    val expenseViewModel: ExpenseViewModel = viewModel(
                        factory = ExpenseViewModelFactory(expenseDao)
                    )

                    ExpenseScreen(
                        expenseViewModel = expenseViewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
