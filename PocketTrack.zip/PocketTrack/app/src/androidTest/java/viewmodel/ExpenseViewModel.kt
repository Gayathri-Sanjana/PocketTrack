package com.example.pockettrack.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pockettrack.data.Expense
import com.example.pockettrack.data.ExpenseDao
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ExpenseViewModel(private val expenseDao: ExpenseDao) : ViewModel() {

    // Use MutableStateFlow for local state management
    private val _expenses = MutableStateFlow<List<Expense>>(emptyList())
    val expenses: StateFlow<List<Expense>> = _expenses.asStateFlow()

    private val _totalExpense = MutableStateFlow(0.0)
    val totalExpense: StateFlow<Double> = _totalExpense.asStateFlow()

    init {
        observeExpenses()
        observeTotalExpense()
    }

    private fun observeExpenses() {
        viewModelScope.launch {
            expenseDao.getAllExpenses()
                .collect { expenseList ->
                    _expenses.value = expenseList
                }
        }
    }

    private fun observeTotalExpense() {
        viewModelScope.launch {
            expenseDao.getTotalExpense()
                .map { it ?: 0.0 }
                .collect { total ->
                    _totalExpense.value = total
                }
        }
    }

    // Function to add an expense
    fun addExpense(description: String, amount: Double, date: Long) {
        val expense = Expense(description = description, amount = amount, date = date)
        viewModelScope.launch {
            expenseDao.insertExpense(expense)
        }
    }

    // Function to format date
    fun formatDate(timestamp: Long): String {
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return dateFormat.format(Date(timestamp))
    }

    // Function to get total expenses
    fun getTotalExpenses(): Double {
        return totalExpense.value
    }
}
