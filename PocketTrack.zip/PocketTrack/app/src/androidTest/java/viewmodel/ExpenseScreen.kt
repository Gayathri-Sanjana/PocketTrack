package com.example.pockettrack.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.pockettrack.viewmodel.ExpenseViewModel
import com.example.pockettrack.data.Expense

@Composable
fun ExpenseScreen(
    expenseViewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val expenses by expenseViewModel.expenses.collectAsState()
    val totalExpense by expenseViewModel.totalExpense.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Expense")
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Text(
                text = "Total Expenses: ₹$totalExpense",
                style = MaterialTheme.typography.headlineSmall.copy(color = Color.Gray)
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(expenses) { expense ->
                    ExpenseItem(expenseViewModel, expense)
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Add Expense", style = MaterialTheme.typography.headlineSmall) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Description") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = amount,
                            onValueChange = { amount = it },
                            label = { Text("Amount") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (description.isNotBlank() && amount.isNotBlank()) {
                            val expenseAmount = amount.toDoubleOrNull()
                            if (expenseAmount != null && expenseAmount > 0) {
                                expenseViewModel.addExpense(
                                    description = description,
                                    amount = expenseAmount,
                                    date = System.currentTimeMillis()
                                )
                                description = ""
                                amount = ""
                                showDialog = false
                            } else {
                                Toast.makeText(context, "Please enter a valid number for amount", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text("Add", style = MaterialTheme.typography.bodyMedium)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showDialog = false }) {
                        Text("Cancel", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            )
        }
    }
}

@Composable
fun ExpenseItem(viewModel: ExpenseViewModel, expense: Expense) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = expense.description, style = MaterialTheme.typography.titleMedium, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "₹${expense.amount}", style = MaterialTheme.typography.bodyLarge, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = viewModel.formatDate(expense.date), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}
